# PDex Multi-Member Match Result Value Set - Da Vinci Payer Data Exchange v2.2.0

* [**Table of Contents**](toc.md)
* [**FHIR Artifacts**](artifacts.md)
* **PDex Multi-Member Match Result Value Set**

## ValueSet: PDex Multi-Member Match Result Value Set 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/us/davinci-pdex/ValueSet/PDexMultiMemberMatchResultVS | *Version*:2.2.0 | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:PDexMultiMemberMatchResultVS |
| **Copyright/Legal**: Used by permission of HL7 International, all rights reserved Creative Commons License | | |

 
Codes to describe the results group from a multi-member Match operation or Member Attribution Process. 

 **References** 

* [PDex Member Match Group](StructureDefinition-pdex-member-match-group.md)
* [PDex Member Match Group](StructureDefinition-pdex-member-match-group.md)
* [PDex Member No Match Group](StructureDefinition-pdex-member-no-match-group.md)
* [PDex Member No Match Group](StructureDefinition-pdex-member-no-match-group.md)
* [Member Opt-Out Group](StructureDefinition-pdex-member-opt-out.md)
* [Member Opt-Out Group](StructureDefinition-pdex-member-opt-out.md)
* [PDex Provider Group](StructureDefinition-pdex-provider-group.md)
* [PDex Provider Group](StructureDefinition-pdex-provider-group.md)
* [Provider Member Match Group](StructureDefinition-pdex-provider-member-match.md)
* [Provider Member Match Group](StructureDefinition-pdex-provider-member-match.md)
* [Provider Member No Match Group](StructureDefinition-pdex-provider-member-no-match.md)
* [Provider Member No Match Group](StructureDefinition-pdex-provider-member-no-match.md)
* [Member-Provider Treatment Relationship Group](StructureDefinition-pdex-treatment-relationship.md)
* [Member-Provider Treatment Relationship Group](StructureDefinition-pdex-treatment-relationship.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "PDexMultiMemberMatchResultVS",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "fm"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://hl7.org/fhir/us/davinci-pdex/ImplementationGuide/hl7.fhir.us.davinci-pdex"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://hl7.org/fhir/us/davinci-pdex/ImplementationGuide/hl7.fhir.us.davinci-pdex"
      }]
    }
  }],
  "url" : "http://hl7.org/fhir/us/davinci-pdex/ValueSet/PDexMultiMemberMatchResultVS",
  "version" : "2.2.0",
  "name" : "PDexMultiMemberMatchResultVS",
  "title" : "PDex Multi-Member Match Result Value Set",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-03-17T22:49:33-04:00",
  "publisher" : "HL7 International / Financial Management",
  "contact" : [{
    "name" : "HL7 International / Financial Management",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.hl7.org/Special/committees/fm"
    },
    {
      "system" : "email",
      "value" : "fm@lists.HL7.org"
    }]
  },
  {
    "name" : "Mark Scrimshire (mark.scrimshire@onyxhealth.io)",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:mark.scrimshire@onyxhealth.io"
    }]
  },
  {
    "name" : "HL7 International - Financial Management",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.hl7.org/Special/committees/fm"
    }]
  }],
  "description" : "Codes to describe the results group from a multi-member Match operation or Member Attribution Process.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "US",
      "display" : "United States of America"
    }]
  }],
  "copyright" : "Used by permission of HL7 International, all rights reserved Creative Commons License",
  "compose" : {
    "include" : [{
      "system" : "http://hl7.org/fhir/us/davinci-pdex/CodeSystem/PdexMultiMemberMatchResultCS"
    },
    {
      "system" : "http://hl7.org/fhir/us/davinci-pdex/CodeSystem/PdexMemberAttributionCS"
    }]
  }
}

```
