# example-pdex-member-no-match-group - Da Vinci Payer Data Exchange v2.2.0

* [**Table of Contents**](toc.md)
* [**FHIR Artifacts**](artifacts.md)
* **example-pdex-member-no-match-group**

## Example Group: example-pdex-member-no-match-group

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

Default Generated text for resource.



## Resource Content

```json
{
  "resourceType" : "Group",
  "id" : "example-pdex-member-no-match-group",
  "meta" : {
    "lastUpdated" : "2024-03-20T09:00:00.000Z",
    "profile" : ["http://hl7.org/fhir/us/davinci-pdex/StructureDefinition/pdex-member-no-match-group"]
  },
  "contained" : [{
    "resourceType" : "Patient",
    "id" : "3",
    "identifier" : [{
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "MB"
        }]
      },
      "system" : "http://example.org/new-payer/identifiers/member",
      "value" : "45567",
      "assigner" : {
        "display" : "New Payer"
      }
    }],
    "name" : [{
      "use" : "official",
      "family" : "Jones",
      "given" : ["Adam", "Jacob"]
    }],
    "gender" : "male",
    "birthDate" : "1957-12-25"
  }],
  "identifier" : [{
    "system" : "http://hl7.org/fhir/sid/us-npi",
    "value" : "0123456789"
  }],
  "type" : "person",
  "actual" : true,
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/us/davinci-pdex/CodeSystem/PdexMultiMemberMatchResultCS",
      "code" : "nomatch",
      "display" : "Not Matched"
    }]
  },
  "managingEntity" : {
    "identifier" : {
      "system" : "http://hl7.org/fhir/sid/us-npi",
      "value" : "9876543210"
    },
    "display" : "Old Health Plan"
  },
  "member" : [{
    "entity" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/us/davinci-pdex/StructureDefinition/base-ext-match-parameters",
        "valueReference" : {
          "reference" : "#3"
        }
      }],
      "reference" : "#3"
    }
  }]
}

```
