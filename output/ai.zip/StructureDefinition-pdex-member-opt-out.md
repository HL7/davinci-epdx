# Member Opt-Out Group - Da Vinci Payer Data Exchange v2.2.0

* [**Table of Contents**](toc.md)
* [**FHIR Artifacts**](artifacts.md)
* **Member Opt-Out Group**

## Resource Profile: Member Opt-Out Group 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/us/davinci-pdex/StructureDefinition/pdex-member-opt-out | *Version*:2.2.0 | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:MemberOptOut |
| **Copyright/Legal**: Used by permission of HL7 International, all rights reserved Creative Commons License | | |

 
A Group resource representing members who have opted out of Provider Access API data sharing. **Intended use:** this profile is offered as a payer-internal FHIR-based scaffolding pattern that implementers MAY adopt when their existing platform (legacy system, vendor product, internal API) cannot itself act as the authoritative reference source for opt-out determinations. Implementers whose existing systems can answer opt-out queries authoritatively are not required to use this profile. **Secondary use:** the same profile serves as the wire-format target profile for the `ConsentConstrainedMembers` output of the `$provider-member-match` operation; a ConsentConstrainedMembers Group returned by that operation conforms to this profile regardless of the mechanism the payer uses internally to determine opt-out status. **Privacy default — SHOULD suppress when opt-out status is sensitive.** Where a payer determines that disclosing opt-out status to a requesting provider would itself constitute a disclosure the member did not authorize (whether under applicable state privacy law, the member's stated preference, or the payer's privacy policy), the payer **SHOULD** suppress the `ConsentConstrainedMembers` output of `$provider-member-match` and instead include the affected members in the `NonMatchedMembers` Group; this makes the response indistinguishable to the requester between a true no-match and a matched-but-opted-out outcome. The internal-tracking use of this profile is unaffected by that choice. **Distinguishing master-list instances from operation-emitted response instances.** Both the payer-internal master opt-out list and the response Group emitted by `$provider-member-match` conform to this profile, so a payer storing both must distinguish them at query time. The recommended discriminator is `Group.identifier`: the payer SHOULD assign master-list instances a `Group.identifier` with a payer-defined `system` URI such as `https://{payer}/fhir/identifier/master-opt-out-list` (and a stable `value`), while operation-emitted response instances either omit `Group.identifier` or use a distinct system URI such as `https://{payer}/fhir/identifier/match-result`. Payers that prefer a tag-based discriminator MAY instead use `Group.meta.tag` with a payer-defined coding. `Group.code` is **not** a reliable discriminator here because it is fixed-pattern to `PdexMultiMemberMatchResultCS#consentconstraint` on every conformant instance (see FHIR-56493). The Payer is the managing organization, and Group.member entries reference the patients who have exercised their right to opt-out, either broadly or for specific purposes or providers. 

**Usages:**

* Use this Profile: [Provider $multi-member-match Response](StructureDefinition-provider-parameters-multi-member-match-bundle-out.md)
* Examples for this Profile: [Group/member-opt-out-group-001](Group-member-opt-out-group-001.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.fhir.us.davinci-pdex|current/StructureDefinition/StructureDefinition-pdex-member-opt-out.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-pdex-member-opt-out.csv), [Excel](StructureDefinition-pdex-member-opt-out.xlsx), [Schematron](StructureDefinition-pdex-member-opt-out.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "pdex-member-opt-out",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "fm"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://hl7.org/fhir/us/davinci-pdex/ImplementationGuide/hl7.fhir.us.davinci-pdex"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://hl7.org/fhir/us/davinci-pdex/ImplementationGuide/hl7.fhir.us.davinci-pdex"
      }]
    }
  }],
  "url" : "http://hl7.org/fhir/us/davinci-pdex/StructureDefinition/pdex-member-opt-out",
  "version" : "2.2.0",
  "name" : "MemberOptOut",
  "title" : "Member Opt-Out Group",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-12-16T00:00:00Z",
  "publisher" : "HL7 International / Financial Management",
  "contact" : [{
    "name" : "HL7 International / Financial Management",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.hl7.org/Special/committees/fm"
    },
    {
      "system" : "email",
      "value" : "fm@lists.HL7.org"
    }]
  },
  {
    "name" : "Mark Scrimshire (mark.scrimshire@onyxhealth.io)",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:mark.scrimshire@onyxhealth.io"
    }]
  },
  {
    "name" : "HL7 International - Financial Management",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.hl7.org/Special/committees/fm"
    }]
  }],
  "description" : "A Group resource representing members who have opted out of Provider Access API data sharing. **Intended use:** this profile is offered as a payer-internal FHIR-based scaffolding pattern that implementers MAY adopt when their existing platform (legacy system, vendor product, internal API) cannot itself act as the authoritative reference source for opt-out determinations. Implementers whose existing systems can answer opt-out queries authoritatively are not required to use this profile. **Secondary use:** the same profile serves as the wire-format target profile for the `ConsentConstrainedMembers` output of the `$provider-member-match` operation; a ConsentConstrainedMembers Group returned by that operation conforms to this profile regardless of the mechanism the payer uses internally to determine opt-out status. **Privacy default — SHOULD suppress when opt-out status is sensitive.** Where a payer determines that disclosing opt-out status to a requesting provider would itself constitute a disclosure the member did not authorize (whether under applicable state privacy law, the member's stated preference, or the payer's privacy policy), the payer **SHOULD** suppress the `ConsentConstrainedMembers` output of `$provider-member-match` and instead include the affected members in the `NonMatchedMembers` Group; this makes the response indistinguishable to the requester between a true no-match and a matched-but-opted-out outcome. The internal-tracking use of this profile is unaffected by that choice. **Distinguishing master-list instances from operation-emitted response instances.** Both the payer-internal master opt-out list and the response Group emitted by `$provider-member-match` conform to this profile, so a payer storing both must distinguish them at query time. The recommended discriminator is `Group.identifier`: the payer SHOULD assign master-list instances a `Group.identifier` with a payer-defined `system` URI such as `https://{payer}/fhir/identifier/master-opt-out-list` (and a stable `value`), while operation-emitted response instances either omit `Group.identifier` or use a distinct system URI such as `https://{payer}/fhir/identifier/match-result`. Payers that prefer a tag-based discriminator MAY instead use `Group.meta.tag` with a payer-defined coding. `Group.code` is **not** a reliable discriminator here because it is fixed-pattern to `PdexMultiMemberMatchResultCS#consentconstraint` on every conformant instance (see FHIR-56493). The Payer is the managing organization, and Group.member entries reference the patients who have exercised their right to opt-out, either broadly or for specific purposes or providers.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "US",
      "display" : "United States of America"
    }]
  }],
  "copyright" : "Used by permission of HL7 International, all rights reserved Creative Commons License",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Group",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Group",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Group",
      "path" : "Group"
    },
    {
      "id" : "Group.identifier",
      "path" : "Group.identifier",
      "short" : "Unique identifier for the opt-out group",
      "definition" : "Business identifier assigned by the payer to uniquely identify this opt-out group",
      "mustSupport" : true
    },
    {
      "id" : "Group.active",
      "path" : "Group.active",
      "short" : "Opt-out group is active",
      "definition" : "Indicates whether this opt-out group is active and current",
      "patternBoolean" : true,
      "mustSupport" : true
    },
    {
      "id" : "Group.type",
      "path" : "Group.type",
      "short" : "Type of group (members)",
      "definition" : "Fixed to 'person' to represent a collection of individual members",
      "patternCode" : "person",
      "mustSupport" : true
    },
    {
      "id" : "Group.actual",
      "path" : "Group.actual",
      "short" : "This is an actual collection of members",
      "definition" : "Indicates this is an actual group of members, not a virtual group",
      "patternBoolean" : true,
      "mustSupport" : true
    },
    {
      "id" : "Group.code",
      "path" : "Group.code",
      "short" : "Kind of group (opt-out)",
      "definition" : "Classification for this opt-out group. Fixed to `consentconstraint` because this profile represents only the consent-constrained / opt-out outcome from a multi-member match; the other codes in `PDexMultiMemberMatchResultVS` (`match`, `nomatch`) are not semantically applicable to instances of this profile.",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/us/davinci-pdex/CodeSystem/PdexMultiMemberMatchResultCS",
          "code" : "consentconstraint",
          "display" : "Consent Constraint"
        }]
      },
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/us/davinci-pdex/ValueSet/PDexMultiMemberMatchResultVS"
      }
    },
    {
      "id" : "Group.quantity",
      "path" : "Group.quantity",
      "short" : "Number of members who have opted out",
      "definition" : "The count of members in this opt-out group",
      "mustSupport" : true
    },
    {
      "id" : "Group.managingEntity",
      "path" : "Group.managingEntity",
      "short" : "The Payer managing this opt-out group",
      "definition" : "Reference to the Payer organization that is managing and maintaining this opt-out group. Constrained to Organization since the managing entity is always a Payer (i.e., a healthcare organization), not a Practitioner, PractitionerRole, or RelatedPerson.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Group.characteristic",
      "path" : "Group.characteristic",
      "short" : "Opt-out characteristics and scope",
      "definition" : "Characteristics describing the nature and scope of the opt-out",
      "mustSupport" : true
    },
    {
      "id" : "Group.characteristic.extension",
      "path" : "Group.characteristic.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Group.characteristic.extension:optOutReason",
      "path" : "Group.characteristic.extension",
      "sliceName" : "optOutReason",
      "short" : "Reason for the opt-out",
      "definition" : "The member's stated reason for opting out",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/us/davinci-pdex/StructureDefinition/opt-out-reason"]
      }]
    },
    {
      "id" : "Group.characteristic.code",
      "path" : "Group.characteristic.code",
      "short" : "Identifies this as a consent constraint group",
      "definition" : "Fixed code indicating this group contains members with consent constraints (opt-outs)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/us/davinci-pdex/CodeSystem/PdexMultiMemberMatchResultCS",
          "code" : "consentconstraint",
          "display" : "Consent Constraint"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Group.characteristic.code.coding",
      "path" : "Group.characteristic.code.coding",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/us/davinci-pdex/ValueSet/PDexMultiMemberMatchResultVS"
      }
    },
    {
      "id" : "Group.characteristic.value[x]",
      "path" : "Group.characteristic.value[x]",
      "short" : "The type of opt-out",
      "definition" : "Indicates whether the opt-out is global, provider-specific, or purpose-specific",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/us/davinci-pdex/ValueSet/opt-out-scope-valueset"
      }
    },
    {
      "id" : "Group.characteristic.exclude",
      "path" : "Group.characteristic.exclude",
      "short" : "This is an include, not an exclude",
      "definition" : "Members are included, not excluded",
      "patternBoolean" : false
    },
    {
      "id" : "Group.characteristic.period",
      "path" : "Group.characteristic.period",
      "short" : "Period during which the opt-out is effective",
      "definition" : "Start date when the opt-out becomes effective; optionally includes an end date",
      "mustSupport" : true
    },
    {
      "id" : "Group.characteristic.period.start",
      "path" : "Group.characteristic.period.start",
      "short" : "Opt-out effective date",
      "mustSupport" : true
    },
    {
      "id" : "Group.member",
      "path" : "Group.member",
      "short" : "Members who have opted out",
      "definition" : "List of patients/members who have opted out of data sharing",
      "mustSupport" : true
    },
    {
      "id" : "Group.member.entity",
      "path" : "Group.member.entity",
      "short" : "Member/patient who has opted out",
      "definition" : "Reference to a Patient resource for a member who has opted out",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Group.member.entity.extension:optOutDetails",
      "path" : "Group.member.entity.extension",
      "sliceName" : "optOutDetails",
      "short" : "Details of the member's opt-out",
      "definition" : "Additional details about when and why the member opted out",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/us/davinci-pdex/StructureDefinition/opt-out-details"]
      }]
    },
    {
      "id" : "Group.member.inactive",
      "path" : "Group.member.inactive",
      "short" : "Whether the opt-out is currently active",
      "definition" : "Set to false/not present if the opt-out is active; set to true if revoked/inactive"
    }]
  }
}

```
