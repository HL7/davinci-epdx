# OrganizationPayer1 - Da Vinci Payer Data Exchange v2.1.1

* [**Table of Contents**](toc.md)
* [**FHIR Artifacts**](artifacts.md)
* **OrganizationPayer1**

## Example Organization: OrganizationPayer1

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

Last updated: 2019-12-12 09:14:11+0000; Language: en-US

Profile: [US Core Organization Profile](http://hl7.org/fhir/us/core/STU7/StructureDefinition-us-core-organization.html)

**identifier**: National provider identifier/1022248102

**active**: true

**name**: Payer 1



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "Payer1",
  "meta" : {
    "lastUpdated" : "2019-12-12T09:14:11+00:00",
    "profile" : [
      "http://hl7.org/fhir/us/core/StructureDefinition/us-core-organization"
    ]
  },
  "language" : "en-US",
  "identifier" : [
    {
      "type" : {
        "coding" : [
          {
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "NPI"
          }
        ]
      },
      "system" : "http://hl7.org/fhir/sid/us-npi",
      "value" : "1022248102"
    }
  ],
  "active" : true,
  "name" : "Payer 1"
}

```
